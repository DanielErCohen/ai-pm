# PM digest

Get your PM newsletters as one 4-minute digest, twice a week.

<details>
<summary><b>Why I built it:</b> I subscribed to more product newsletters than I could read, so a routine now aggregates them into one digest.</summary>

- The digest arrives Monday and Thursday morning: 4 headlines, one product-sense drill from a 24-topic curriculum and one thing to use this week.
- A cap on each section keeps a read to about 4 minutes.
- The routine stores its state in the sent email's footer, so it needs no database.

</details>

It is a cloud routine that reads a curated set of product newsletters from my inbox and sends one short digest: 4 headlines, one product-sense drill, product news, tech, AI in PM and a line on how to use it this week.

## How it works

- **Schedule:** Monday and Thursday morning, as a Claude Code cloud routine with the Gmail connector and WebFetch. The prompt is in [`routine-prompt.md`](routine-prompt.md).
- **State lives in email.** The newest digest with "v3" in its footer sets the window. Each footer records the drill number and topic, so the routine knows which topics it has covered.
- **Sources** come from one Gmail query plus a label you apply. After each run the routine marks the source newsletters read and archives them. It never trashes anything.
- **The drill** comes from a 24-topic curriculum (problem framing, discovery, strategy cascade, metrics, prioritization, experiment design, evals for AI products, pricing, positioning, retention and more). It picks the lowest-numbered topic not yet drilled. Each drill has a scenario, a model answer of at most 5 bullets, and the common mistake.
- **Scenarios use generic companies** (a marketplace, a streaming service, a bank). The reader's own products stay out.

## Sources

| Source | Focus |
|---|---|
| [Lenny's Newsletter](https://www.lennysnewsletter.com), [How I AI](https://www.lennysnewsletter.com/s/how-i-ai), [The Skip](https://theskip.substack.com) | Product craft, growth, AI workflows |
| [Product Growth](https://news.aakashg.com), [AI by Aakash](https://aibyaakash.com) | PM craft, AI PM, careers |
| [Product Compass](https://www.productcompass.pm) (Paweł Huryn) | AI product management, frameworks |
| [GenAI PM Daily](https://genaipm.com) | Daily AI news ranked for PMs |
| [Behind the Craft](https://creatoreconomy.so) (Peter Yang) | AI tools, tutorials, essays |
| [Charlie Hills](https://charliehills.substack.com) | AI content and LinkedIn tactics |
| [Product Institute](https://www.productinstitute.com) (Melissa Perri) | Product strategy, operations, outcomes |
| [cxo.dev](https://cxo.dev) | Tech leadership |
| [Tech Brew](https://www.techbrew.com) (Morning Brew) | General tech news |
| [Product Talk](https://www.producttalk.org) (Teresa Torres) | Continuous discovery |
| [SVPG](https://www.svpg.com/articles/) (Marty Cagan) | Product operating model, empowered teams |
| [The Beautiful Mess](https://cutlefish.substack.com) (John Cutler) | Product operations, org design |

Replace this list with newsletters you read. Add each sender's full address to the Gmail query in the prompt. Gmail filters and `from:` searches in the routine only match full addresses.

## Setup

1. Subscribe to the newsletters. Create a Gmail label and a filter that applies it to your newsletters.
2. Copy `routine-prompt.md` into the folder where you keep your prompts, and replace each placeholder in angle brackets: your address, your label, your timezone and target hour. `cp -n` never overwrites a file you already have:

   ```bash
   cp -n ~/how-i-work/routines/pm-digest/routine-prompt.md ./my-digest-prompt.md
   ```

3. Create a scheduled routine at [claude.ai/code/routines](https://claude.ai/code/routines), or with `/schedule` in Claude Code. Enable the Gmail connector and WebFetch, and paste the prompt. Schedule it two slots one hour apart in UTC if your timezone has daylight saving, as the time gate in the prompt expects.
4. Run it once by hand and read the result. When the output is wrong, fix the prompt.

## Why it works this way

- State in the sent mail means the routine needs no database, and a failed run leaves nothing half-written.
- Hard caps on each section keep the digest short. The reader's attention is the scarce part.
- Newsletter text is data. The prompt says never to follow instructions found inside it, and fixes the recipient to the one address you set in it.

## Risk

Prompt injection is the risk: a newsletter can hide text that tells the routine to do something else. The routine reads outside text and holds the Gmail connector (read, send and label every mail) and WebFetch. The prompt fixes the recipient and treats newsletter text as data. That lowers the risk and leaves some of it.

To read each digest before anything is sent, replace `send_message` in section 8 of the prompt with `create_draft` and drop the starring line after it. The digest waits in your Gmail drafts, and you send it yourself. Send it before the next run, because the window and the drill history are read from sent digests.
