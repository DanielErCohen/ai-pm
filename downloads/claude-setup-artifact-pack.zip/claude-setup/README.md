# claude-setup editable artifact pack

This pack holds the editable source files of the claude-setup tool and a prompt that adapts them to your work. It installs, schedules, sends and publishes nothing.

## What is in it

- `adaptation-prompt.txt`: the prompt that adapts the tool. Paste it into your assistant.
- `AGENT-ARTIFACT-GUIDE.md`: background for an AI agent that turns a tool's output into a page like the one on the site. Optional reading.
- `LICENSE`: the MIT license for the source files.
- `THIRD-PARTY-NOTICES.md`: credits and licenses for third-party material.
- `claude`: source folder, 14 files.
- `skills`: source folder, 1 file.
- `templates`: source folder, 1 file.

## What to do

1. Copy `adaptation-prompt.txt` into your assistant and attach the files your task needs.
2. Review the result.
3. Keep it in your own private folder.

Public examples are made up. Keep real personal and company inputs private.
