---
name: feedback-keep-source-and-inference-separate
description: When summarizing research notes, keep observations separate from interpretations
type: feedback
---

Made-up teaching example. The preference and incidents below were made up for this file.

Keep an observation's source and date beside it. Put an interpretation in a separate sentence and label what remains unknown.

Why: in this made-up workflow, two research summaries turned a participant's request into a claim about the whole customer segment. The source notes described one participant in each session.

How to apply: when summarizing a source note, state who was observed by role, the task and the coverage. Label a broader claim as a hypothesis until additional evidence supports it. If the source or date is missing, write "unknown" and leave the claim open for review.
