# Worked example

Everything here is made-up: the person, the employers and the numbers are made up. It shows the flow in `marlow-quinnet/`:

1. `main-cv.md`: the main CV of a made-up customer success manager.
2. `job-description.md` and `company-notes.md`: a made-up posting at a made-up company.
3. `cv.md`: the tailored CV.
4. `changes.md`: what changed against the main CV, and why. This file also shows a gap that stays a gap and a simulated "Read as the recipients" section.
5. `cover-note.md`: the short note.

Use it as a format reference. Delete the folder from your private copy if you like.
