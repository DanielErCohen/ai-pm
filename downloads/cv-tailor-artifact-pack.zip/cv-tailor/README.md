# cv-tailor editable artifact pack

This pack holds the editable source files of the cv-tailor tool and a prompt that adapts them to your work. It installs, schedules, sends and publishes nothing.

## What is in it

- `adaptation-prompt.txt`: the prompt that adapts the tool. Paste it into your assistant.
- `AGENT-ARTIFACT-GUIDE.md`: background for an AI agent that turns a tool's output into a page like the one on the site. Optional reading.
- `LICENSE`: the MIT license for the source files.
- `CLAUDE.md`: source file.
- `applications`: source folder, 6 files.
- `examples`: source folder, 7 files.
- `guides`: source folder, 7 files.
- `my-cv`: source folder, 2 files.
- `skills`: source folder, 6 files.

## What to do

1. Copy `adaptation-prompt.txt` into your assistant and attach the files your task needs.
2. Review the result.
3. Keep it in your own private folder.

Public examples are made up. Keep real personal and company inputs private.
